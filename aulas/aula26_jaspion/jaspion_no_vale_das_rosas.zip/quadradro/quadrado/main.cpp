#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <ctime>
#include <cstdlib>

using namespace std;
using namespace sf;

struct Boneco{
    int tam;
    int x;
    int y;
    sf::Texture textura;
    sf::Sprite sprite;

    Boneco(int x, int y, int tam){
        this->x = x;
        this->y = y;
        if(!textura.loadFromFile("../imagens/jaspion.png"))
            cout << "Figura nao encontrada\n";
        sprite.setTexture(textura);
        float largura = sprite.getGlobalBounds().width;
        float altura  = sprite.getGlobalBounds().height;
        sprite.setScale(tam/largura, tam/altura);
    }

    void draw(RenderWindow & win){
        sprite.setPosition(x, y);
        win.draw(sprite);
    }

    void processarMovimento(vector<RectangleShape> & pedras){
        int xold = x;
        int yold = y;
        if(sf::Keyboard::isKeyPressed(Keyboard::Right)){
            x += 5;
        }
        if(sf::Keyboard::isKeyPressed(Keyboard::Left)){
            x -= 5;
        }
        if(sf::Keyboard::isKeyPressed(Keyboard::Up)){
            y -= 5;
        }
        if(sf::Keyboard::isKeyPressed(Keyboard::Down)){
            y += 5;
        }
        sprite.setPosition(x, y);
        for(auto pedra : pedras){
            if(sprite.getGlobalBounds().intersects(
                        pedra.getGlobalBounds())){
                x = xold;
                y = yold;
                break;
            }
        }
    }

};

int main()
{
    RenderWindow win(sf::VideoMode(800, 600), "QUA");
    Texture tcaminho;
    tcaminho.loadFromFile("../imagens/caminho.jpg");
    Sprite fundo(tcaminho);
    Color background(Color::Black);
    srand(time(0));

    vector<RectangleShape> pedras;
    for(int i = 0; i < 10; i++){
        RectangleShape pedra(Vector2f(10, 10));
        pedra.setPosition(rand()%500, rand()%500);
        pedras.push_back(pedra);
    }

    Boneco jaspion(100, 200, 100);


    while(win.isOpen()){
        Event event;
        while(win.pollEvent(event)){
            if(event.type == Event::Closed)
                win.close();
            if(event.type == Event::KeyPressed){
                if(event.key.code == Keyboard::Space)
                    win.close();
                if(event.key.code == Keyboard::C){
                    background.r = rand() % 255;
                    background.g = rand() % 255;
                    background.b = rand() % 255;
                }
            }
        }
        jaspion.processarMovimento(pedras);
        //win.clear(background);
        win.draw(fundo);

        for(auto pedra : pedras)
            win.draw(pedra);
        jaspion.draw(win);
        //win.draw(pedra);


        win.display();

    }

    return 0;
}

